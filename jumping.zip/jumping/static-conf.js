'use strict';

module.exports = {
  staticPath: {
    'create.min.js': ['/static/js/createjs.min.js'],
  }
};
